#0 3 * * 0 sh /u01/app/oracle/backuptest_store/backup_database.sh /u01/app/oracle/product/19.0.0 19c oradbwr lv0 compress /u01/app/oracle/backuptest_store/database /u01/app/oracle/backuptest_store/archivelog 3 10 /u01/app/oracle/backuptest_store/logs

#0 3 * * 1,2,3,4,5,6 sh /u01/app/oracle/backuptest_store/backup_database.sh /u01/app/oracle/product/19.0.0 19c oradbwr lv1 compress /u01/app/oracle/backuptest_store/database /u01/app/oracle/backuptest_store/archivelog 3 10 /u01/app/oracle/backuptest_store/logs

