#sh /home/oracle/scripts/backup_database.sh {ORACLE_HOME} {ORACLE_VERSION} {ORACLE_SID} {BACKUP_TYPE} {COMPRESS} {BACKUP_PATH} {ARCHIVE_BACKUP_PATH} {BACKUP_RETENTION} {ARCHIVE_RETENTION} {LOG_PATH}

#!/bin/sh
#*********************************************************
# Script backup database
#
# arg[1]: oracle home path      - ex: /u01/app/oracle/product/11.2.0/db_1
# arg[2]: oracle version        - ex: 9i, 10g, 11g, 12c
# arg[3]: sid of database       - ex: oradbwr, ITIL1, WTB
# arg[4]: backup type           - (full, lv0, lv1, lv1c)
# arg[5]: backup path           - ex: /u01/app/oracle/backuptest_store/database
# arg[6]: archivelog backup path - ex: /u01/app/oracle/backuptest_store/archivelog
# arg[7]: backup retention      - ex: 3
# arg[8]: log path	        - ex: /u01/app/oracle/backuptest_store/logs
#
# Created by: DBA -
#
#*********************************************************

export ORACLE_HOME=$1
export ORACLE_VERSION=$2
export ORACLE_SID=$3
export LEVEL_BACKUP=$4
export COMPRESS=$5
export BACKUP_PATH=$6
export ARCHIVE_BACKUP_PATH=$7
export BACKUP_RETENTION=$8
export ARCHIVE_RETENTION=$9
export LOG_PATH=${10}
export START_TIME=$(date +%d%h%y_%H%M%S)
export START_TIME1=$(date +%Y%m%d_%H%M%S)
echo $START_TIME
echo "ORACLE_HOME" $1
echo "ORACLE_VERSION" $2
echo "ORACLE_SID" $3
echo "LEVEL_BACKUP" $4
echo "COMPRESS" $5
echo "BACKUP_PATH" $6
echo "ARCHIVE_BACKUP_PATH" $7
echo "BACKUP_RETENTION" $8
echo "ARCHIVE_RETENTION" $9
echo "LOG_PATH" ${10}

export PATH=$ORACLE_HOME:$ORACLE_HOME/bin:$PATH

if [[ ${LEVEL_BACKUP} = "full" ]] 
then BACKUP_TYPE="full";
fi
if [[ ${LEVEL_BACKUP} = "lv0" ]] 
then BACKUP_TYPE="incremental level 0";
fi
if [[ ${LEVEL_BACKUP} = "lv1" ]] 
then BACKUP_TYPE="incremental level 1";
fi
if [[ ${LEVEL_BACKUP} = "lv1c" ]]
then BACKUP_TYPE="incremental level 1 cumulative";
fi
export BACKUP_TYPE
echo ${BACKUP_TYPE}
COM="as backupset";

if [ ${COMPRESS} = "compress" ] 
then COM="as compressed backupset";
fi
if [[ ${ORACLE_VERSION} = "9i" ]] 
then COM="";BACKUP_TYPE="";
fi

LOG_FILE=${LOG_PATH}/${START_TIME1}_${ORACLE_SID}_${LEVEL_BACKUP}.log
echo "LOG: "${LOG_FILE}

echo "Start backup: $(date)" >> ${LOG_FILE}
#---------------------Rman SQL----------------------------
#rman target rman/rman1893728462@${ORACLE_SID} log=${LOG_FILE} <<EOF

rman target / log=${LOG_FILE} <<EOF
run{
   CONFIGURE DEFAULT DEVICE TYPE TO DISK;
   CONFIGURE CONTROLFILE AUTOBACKUP OFF;
   CONFIGURE RETENTION POLICY TO REDUNDANCY ${BACKUP_RETENTION};
   CONFIGURE CHANNEL DEVICE TYPE DISK MAXPIECESIZE = 20G;
   delete noprompt obsolete REDUNDANCY ${BACKUP_RETENTION} device type disk;
   backup ${COM} ${BACKUP_TYPE} database format "${BACKUP_PATH}/%T_%d_backupset_data_${LEVEL_BACKUP}_${COMPRESS}_%U.bkp" tag "${START_TIME}_${LEVEL_BACKUP}_DATA";
   backup spfile format "${BACKUP_PATH}/%T_%d_backupset_spfile_%U.bkp" tag "${START_TIME}_${LEVEL_BACKUP}_Spfile";
   backup device type disk format "${BACKUP_PATH}/%T_%d_backupset_ctl_%U.ctl" current controlfile tag "${START_TIME}_${LEVEL_BACKUP}_Ctl";
   backup device type disk format "${BACKUP_PATH}/%T_%d_backupset_ctl_stb_%U.bkp" current controlfile for standby tag "${START_TIME}_${LEVEL_BACKUP}_Ctl_STB";
   sql "alter system archive log current";

   configure backup optimization on;
   allocate channel ch1 device type disk format = "${ARCHIVE_BACKUP_PATH}/%T_%d_archive_${COMPRESS}_%u_%s_%p.bkp";
   backup ${COM} archivelog from time 'sysdate-2' until time 'sysdate' tag "${START_TIME}_ARCHIVELOG";
   release channel ch1;
  }
   allocate channel for maintenance type disk; 
   crosscheck archivelog all;
   delete force noprompt archivelog until time='sysdate-${ARCHIVE_RETENTION}';
   crosscheck backup;
   crosscheck copy;
   report obsolete REDUNDANCY ${BACKUP_RETENTION};
   delete noprompt obsolete REDUNDANCY ${BACKUP_RETENTION} DEVICE TYPE DISK;
   
EOF
#--------------------------------------------------------------------------------
echo "End backup: $(date)" >> ${LOG_FILE}
